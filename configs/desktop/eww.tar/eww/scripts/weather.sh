#!/usr/bin/env bash

LAT="23.8103"
LON="90.4125"

json="$(
  curl -fsS --max-time 8     "https://api.open-meteo.com/v1/forecast?latitude=${LAT}&longitude=${LON}&current=weather_code&daily=temperature_2m_max,temperature_2m_min&forecast_days=1&timezone=auto"     2>/dev/null
)" || {
  printf '%s\n' '☁ --° --°'
  exit 0
}

printf '%s' "$json" | python3 -c '
import json, sys

try:
    d = json.load(sys.stdin)
    code = int(d["current"]["weather_code"])
    high = round(float(d["daily"]["temperature_2m_max"][0]))
    low = round(float(d["daily"]["temperature_2m_min"][0]))

    if code == 0:
        icon = "☼"
    elif code in (1, 2):
        icon = "◐"
    elif code == 3:
        icon = "☁"
    elif code in (45, 48):
        icon = "≋"
    elif code in (51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82):
        icon = "☂"
    elif code in (71, 73, 75, 77, 85, 86):
        icon = "❄"
    elif code in (95, 96, 99):
        icon = "ϟ"
    else:
        icon = "☁"

    print(f"{icon} {high}° {low}°")
except Exception:
    print("☁ --° --°")
'
